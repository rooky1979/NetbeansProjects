package testing;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/**
 *
 * @author sehall
 */
public class DraggableBoxGUI extends JPanel {
    public final int PANEL_WIDTH = 600;
    public final int PANEL_HEIGHT = 600;
    private DrawingPanel drawPanel;
    protected Box box;
    protected boolean boxSelected;
    
    public DraggableBoxGUI() {
        super(new BorderLayout());  
        drawPanel = new DrawingPanel();
        add(drawPanel,BorderLayout.CENTER);
        drawPanel.addMouseListener(drawPanel);
        drawPanel.addMouseMotionListener(drawPanel);
        box = new Box();
    }
    
    protected class Box
    {
        private int x,y;
        private int BOX_SIZE = 50;
        
        public Box()
        {
            x = drawPanel.getWidth()/2;
            y = drawPanel.getHeight()/2;
        }
        public void draw(Graphics g)
        {
            if(boxSelected)
                g.setColor(Color.YELLOW); 
            else 
                g.setColor(Color.RED); 
            g.fillRect(x, y, BOX_SIZE, BOX_SIZE);
        }
        public int getX(){
            return x;
        }
        public int getY()
        {   return y;
        }
        public void setX(int x){
            if(x <= 0)
                this.x = 0;
            else if(x >= (drawPanel.getWidth()-BOX_SIZE))
                this.x = drawPanel.getWidth()-BOX_SIZE;
            else
                this.x = x;
        }
        public void setY(int y)
        {
            if(y <= 0)
                this.y = 0;
            else if(y >= (drawPanel.getHeight()-BOX_SIZE))
                this.y = drawPanel.getHeight()-BOX_SIZE;
            else
                this.y = y;
        }
        public boolean isWithinBoxBound(int xCoord, int yCoord)
        {
            if(xCoord >= this.x && xCoord <= (x+BOX_SIZE) && 
                    yCoord >= this.y && yCoord <= (y+BOX_SIZE))
                return true;
            else return false;
        }
    }
    
    private class DrawingPanel extends JPanel implements MouseListener,MouseMotionListener
    {   public DrawingPanel()
        {   setPreferredSize(new Dimension(PANEL_WIDTH, PANEL_HEIGHT));
            setBackground(Color.WHITE);
        }
        @Override
        public void paintComponent(Graphics g){
            super.paintComponent(g);
            if(box != null)
                box.draw(g);
        }
        
        @Override
        public void mousePressed(MouseEvent e)
        {   if(box.isWithinBoxBound(e.getX(),e.getY()))
                boxSelected = true;
            else boxSelected = false; 
            repaint();
        }
        @Override 
        public void mouseReleased(MouseEvent e)
        {   boxSelected = false; 
            repaint();
        }
        @Override
        public void mouseDragged(MouseEvent e)
        {   if(boxSelected)
            {   box.setX(e.getX());
                box.setY(e.getY());
            }
            repaint();
        }
        //empty definitions
        @Override public void mouseEntered(MouseEvent e){ }
        @Override public void mouseClicked(MouseEvent e){ }
        @Override public void mouseExited(MouseEvent e){  }
        @Override public void mouseMoved(MouseEvent e){ }
    }
    
    public static void main(String[] args) {
        DraggableBoxGUI myPanel = new DraggableBoxGUI();
        JFrame frame = new JFrame("Draggable Box "); //create frame to hold our JPanel subclass	
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.getContentPane().add(myPanel);  //add instance of MyGUI to the frame
        frame.pack(); //resize frame to fit our Jpanel
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(new Point((d.width / 2) - (frame.getWidth() / 2), (d.height / 2) - (frame.getHeight() / 2)));
	//show the frame	
        frame.setVisible(true);
    } 
     
}
