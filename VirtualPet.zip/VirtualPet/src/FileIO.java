
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/*  VIRTUAL PET PROGRAM BASED ON THE 90'S HANDHELD LCD KEYCHAIN GAME*/
/**
 *
 * @author matthewrook - 18007407
 */
public class FileIO {//handles all the File IO
    
    public static void filesaver(VirtualPet pet) throws IOException // to save the .txt file.  Only one file is created as in a real 90's Tamagotchi, only one pet is active at a time
    {
        try
        {
        ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("virtualpet.txt"));
        output.writeObject(pet);
        output.flush();
        output.close();
        }
        catch(IOException e)
        {
            System.err.println("ERROR SAVING FILE: ");
        }        
    }
    public static Object fileloader() throws IOException, ClassNotFoundException // loads the .txt file to continue the current pet where it left off after quitting and saving.   
    {                                                                            // Only one file is available to load from
        Object object = null;
        
        try
        {
        ObjectInputStream input = new ObjectInputStream(new FileInputStream("virtualpet.txt"));
        
        object = input.readObject();
        input.close();

        }
        catch(IOException f)
        {
            System.err.println("FILE NOT FOUND");
        }
        catch(ClassNotFoundException g)
        {
            System.err.println("ERROR WITH OBJECT LOADING");
        }
        return object;
    }
    public static boolean checkFile()// performs a check to determine if there is a file to load and continue the game or no file and start a new game
    {
        File file = new File("virtualpet.txt");
        
        return file.length() != 0;
    }
    
    public static void deleteFile()// if the pet dies, the current pet save file is deleted so the pet cannot be revived or the game continued
    {
        File file = new File("virtualpet.txt");
        file.delete();
    }
}
