
import static java.awt.Color.BLACK;
import java.awt.Graphics;
import java.awt.Point;
import java.io.Serializable;
import sun.java2d.loops.DrawLine;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author matthewrook
 */
public class Line extends Shape implements Serializable{
 
    public Line(Point startPoint)//change to include startpoint when needed
    {
        super(startPoint);
    }
    @Override
    public void draw(Graphics g)
    {
        //draw the line. change if incorrect
        g.setColor(getColour());
        g.drawLine((int)startPoint.getX(), (int)startPoint.getY(),(int)controlPoint.getX(), (int)controlPoint.getY());
    }
 
    /*testing the line class
    public static void main (String[] args)
    {
    Line line = new Line(new Point(60,150));
    
    line.setControlPoint(new Point (800,650));
    
    line.setColour(BLACK);
    
    System.out.println(line.toString());
    }*/
}

