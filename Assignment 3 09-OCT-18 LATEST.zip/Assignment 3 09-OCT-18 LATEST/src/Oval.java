
import java.awt.Graphics;
import java.awt.Point;
import java.io.Serializable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author matthewrook
 */
public class Oval extends Shape implements EnclosesRegion{
    
    protected boolean filled;
    
    public Oval(Point startPoint)//change to include startpoint when needed
    {
        super(startPoint);
    }
    @Override
    public void draw(Graphics g)
    {
        int width = ((int)controlPoint.getX()-(int)startPoint.getX());
        int height = ((int)controlPoint.getY()-(int)startPoint.getY());
        g.setColor(getColour());
        if(filled)
            g.fillOval((int)startPoint.getX()-width,(int)startPoint.getY()-height, 2*width, 2*height);
        else
            g.drawOval((int)startPoint.getX()-width,(int)startPoint.getY()-height, 2*width, 2*height);
    }
    @Override
    public void setFilled(boolean filled)
    {
        this.filled = filled;
    }
}
