/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author matthewrook
 */
import java.awt.BorderLayout; 
import java.awt.Color;          
import java.awt.Dimension;       
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import javax.swing.JPanel;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class MovieBookingGUI extends JPanel implements ActionListener, ListSelectionListener {
    //fields
    private ArrayList<MovieSession> movies;
    private ArrayList<SeatReservation> currentReservation;
    public final int PANEL_WIDTH = 800;
    public final int PANEL_HEIGHT = 800;
    private final int SEAT_ROW = 8;
    private final int SEAT_COL = 6;
    private JRadioButton childButton, adultButton, elderlyButton;
    private JCheckBox complementaryBox;
    private JButton cancelButton, bookButton, exitButton;
    private JButton[][] seatButtons;
    private JList moviesList;
    private DefaultListModel model;
    private JLabel northLabel;
    private MovieSession currentMovie;
    private ImageIcon empty = new ImageIcon("EmptySeat3.jpg");
    private ImageIcon elderly = new ImageIcon("Elderly1.jpg");
    private ImageIcon child = new ImageIcon("Child1.jpg");
    private ImageIcon adult = new ImageIcon("Adult1.jpg");
    private ImageIcon booked = new ImageIcon("Booked.jpg");
    private ImageIcon check = new ImageIcon("check.jpg");
    private ImageIcon cross = new ImageIcon("cross.jpg");
    private ImageIcon film = new ImageIcon("film.jpg");
    private AdultReservation adultReservation;
    private ElderlyReservation elderlyReservation;
    private ChildReservation childReservation;
    private int[][] previousSeat = new int[8][6];


    
    public MovieBookingGUI(ArrayList<MovieSession> movies)
    {
        //centerpanel and seat button setup
        super(new BorderLayout());
        JPanel centerPanel = new JPanel(new GridLayout(8,6));
        centerPanel.setPreferredSize(new Dimension(550,650));
        seatButtons = new JButton[8][6];
        for(int i = 0; i < SEAT_ROW; ++i)
        {
            for(int k = 0; k < SEAT_COL; ++k)
            {
                seatButtons[i][k] = new JButton("[" + MovieSession.convertIndexToRow(i) + "/" + k + "]",empty);
                seatButtons[i][k].setHorizontalTextPosition(JButton.CENTER);
                seatButtons[i][k].setBackground(Color.BLACK);
                seatButtons[i][k].setOpaque(true);
                seatButtons[i][k].setBorderPainted(false);
                seatButtons[i][k].addActionListener(this);
                centerPanel.add(seatButtons[i][k]);
            }
        }
        add(centerPanel, BorderLayout.CENTER);
        
        //add label to north panel
        JPanel northPanel = new JPanel();
        northLabel = new JLabel("The Pendle Stairway - Classic Cinema Club");
        northLabel.setFont(new Font("Ariel", Font.BOLD, 20));
        northPanel.add(northLabel);
        add(northPanel, BorderLayout.NORTH);
        
        //set up buttons and add to south panel
        childButton = new JRadioButton("Child");
        childButton.setEnabled(false);
        adultButton = new JRadioButton("Adult");
        adultButton.setEnabled(false);
        elderlyButton = new JRadioButton("Elderly");
        elderlyButton.setEnabled(false);
        complementaryBox = new JCheckBox("Complementary");
        complementaryBox.addActionListener(this);
        cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(this);
        bookButton = new JButton("Book");
        bookButton.setEnabled(false);
        bookButton.addActionListener(this);
        exitButton = new JButton("Exit");
        exitButton.addActionListener(this);
        
        ButtonGroup buttons = new ButtonGroup();
        buttons.add(childButton);
        buttons.add(adultButton);
        buttons.add(elderlyButton);
        buttons.add(bookButton);
        buttons.add(cancelButton);
        buttons.add(exitButton);
        
        JPanel southPanel = new JPanel();
        southPanel.add(childButton);
        southPanel.add(adultButton);
        southPanel.add(elderlyButton);
        southPanel.add(complementaryBox);
        southPanel.add(bookButton);
        southPanel.add(cancelButton);
        southPanel.add(exitButton);
        add(southPanel,BorderLayout.SOUTH);

        //set up the JList and set the east panel
        this.movies = movies;
        model = new DefaultListModel();
        moviesList = new JList(model);
        moviesList.setFixedCellWidth(200);
        moviesList.setPreferredSize(new Dimension(450,170));
        moviesList.setFont(new Font("Ariel", Font.BOLD,20));
        moviesList.setBackground(Color.LIGHT_GRAY);
        for(int j = 0; j < this.movies.size(); ++j)
        {
        model.addElement(movies.get(j));
        }
        add(moviesList, BorderLayout.EAST);
        moviesList.addListSelectionListener(this);
        
        currentReservation = new ArrayList<>();//array list to hold tentative seat reservations 
        
        JOptionPane.showMessageDialog(this,"BOOKING INSTRUCTIONS\n"
                + "1. Select a film from the list of showings.\n"
                + "2. Select ticket type (Child/Adult/Elderly) and select Complementary for a complementary ticket.\n"
                + "3.  Click \"Book\" to confirm."
                + " Click \"Cancel\" to cancel the current booking and \"Exit\" to exit the booking process.\n\n"
                + "CLick \"OK\" to continue.", "Welcome to The Pendle Stairway - Classic Cinema Club Booking System", JOptionPane.INFORMATION_MESSAGE, film);
    }
    @Override//method for the JList selection
    public void valueChanged(ListSelectionEvent e)
    {
        bookButton.setEnabled(false);
        childButton.setEnabled(true);
        adultButton.setEnabled(true);
        elderlyButton.setEnabled(true);
        currentMovie = (MovieSession)moviesList.getSelectedValue();
        currentReservation.removeAll(currentReservation);

               //do a check on booked seats
        for(int i = 0; i < SEAT_ROW; ++i)
        {
            for(int k = 0; k < SEAT_COL; ++k)
            {
                previousSeat[i][k] = 0;//reset the previousSeat booking array
                if(currentMovie.getSeat(MovieSession.convertIndexToRow(i),k) instanceof SeatReservation)
                {
                    seatButtons[i][k].setEnabled(false);
                    if(currentMovie.getSeat(MovieSession.convertIndexToRow(i),k) instanceof AdultReservation)
                    {
                        seatButtons[i][k].setDisabledIcon(adult);
                    }
                    if(currentMovie.getSeat(MovieSession.convertIndexToRow(i),k) instanceof ChildReservation)
                    {
                        seatButtons[i][k].setDisabledIcon(child);
                    }
                    if(currentMovie.getSeat(MovieSession.convertIndexToRow(i),k) instanceof ElderlyReservation)
                    {
                        seatButtons[i][k].setDisabledIcon(elderly);
                    }
                }
                else
                {
                    seatButtons[i][k].setEnabled(true);
                    seatButtons[i][k].setIcon(empty);
                }
            }
        }
    }
    @Override
    public void actionPerformed(ActionEvent e)
    {       //setup for the tentative bookings
            for(int i = 0; i < SEAT_ROW; ++i)
            {
                for(int k = 0; k < SEAT_COL; ++k)
                {
                    if(e.getSource() == seatButtons[i][k])
                    {
                        if (previousSeat[i][k] == 1)//checks that seat isn't already tentatively taken
                        {
                            bookButton.setEnabled(false);
                            JOptionPane.showMessageDialog(this, "This Seat is already tentatively booked.\nClick \"Cancel\" to clear the booking and start again" , "BOOKING ERROR", JOptionPane.INFORMATION_MESSAGE);     
                            break;
                        }
                        if(elderlyButton.isSelected())
                        {
                            elderlyReservation = new ElderlyReservation(MovieSession.convertIndexToRow(i), k);
                            if(complementaryBox.isSelected())
                            {
                                elderlyReservation.setComplementary(true);
                            }
                            
                            seatButtons[i][k].setIcon(elderly);
                            seatButtons[i][k].setText("[" + MovieSession.convertIndexToRow(i) + "/" + k + "]");
                            seatButtons[i][k].setHorizontalTextPosition(JButton.CENTER);     
                            currentReservation.add(elderlyReservation);
                            previousSeat[i][k] = 1;//makes the array hold one in this seat position for the check
                            bookButton.setEnabled(true);
                            ;
                            
                        }
                        else if (childButton.isSelected())
                        {
                            childReservation = new ChildReservation(MovieSession.convertIndexToRow(i), k);
                            if(complementaryBox.isSelected())
                            {
                                childReservation.setComplementary(true);
                            }
                            seatButtons[i][k].setIcon(child);
                            seatButtons[i][k].setText("[" + MovieSession.convertIndexToRow(i) + "/" + k + "]");
                            seatButtons[i][k].setHorizontalTextPosition(JButton.CENTER);
                            currentReservation.add(childReservation);
                            previousSeat[i][k] = 1;
                            bookButton.setEnabled(true);
                        }
                        else if(adultButton.isSelected())
                        {
                            adultReservation = new AdultReservation(MovieSession.convertIndexToRow(i), k);
                            if(complementaryBox.isSelected())
                            {
                                adultReservation.setComplementary(true);
                            }
                            seatButtons[i][k].setIcon(adult);
                            seatButtons[i][k].setText("[" + MovieSession.convertIndexToRow(i) + "/" + k + "]");
                            seatButtons[i][k].setHorizontalTextPosition(JButton.CENTER);     
                            currentReservation.add(adultReservation);
                            previousSeat[i][k] = 1;
                            bookButton.setEnabled(true);
                        }
                    }
                }
            }
        if(e.getSource() == bookButton)//apply the bookings
        {   
            if(currentMovie.applyBookings(currentReservation) == true)
            {
                float ticketPrice = 0.00f;
                DecimalFormat df = new DecimalFormat("0.00");
                
                for(int i = 0; i < currentReservation.size(); ++i)
                {
                    ticketPrice += currentReservation.get(i).getTicketPrice();
                }
                        
                JOptionPane.showMessageDialog(this,"BOOKING SUCCESSFUL \n" + currentReservation.size()
                   + " x" + ((currentReservation.size()== 1)? " ticket":" tickets")  + " is $" + df.format(ticketPrice) + " total.", "BOOKING CONFIRMED", JOptionPane.INFORMATION_MESSAGE, check);
                
                currentReservation.removeAll(currentReservation);
                
                for(int k = 0; k < SEAT_ROW; ++k)//block out the successful bookings
                {
                    for(int m = 0; m < SEAT_COL; ++m)
                    {
                        if(currentMovie.isSeatAvailable(MovieSession.convertIndexToRow(k),m) == false)
                        {
                            seatButtons[k][m].setEnabled(false);
                            if(currentMovie.getSeat(MovieSession.convertIndexToRow(k),m) instanceof AdultReservation)
                            {
                                seatButtons[k][m].setDisabledIcon(adult);
                            }
                            if(currentMovie.getSeat(MovieSession.convertIndexToRow(k),m) instanceof ChildReservation)
                            {
                                seatButtons[k][m].setDisabledIcon(child);
                            }
                            if(currentMovie.getSeat(MovieSession.convertIndexToRow(k),m) instanceof ElderlyReservation)
                            {
                                seatButtons[k][m].setDisabledIcon(elderly);
                            }
                        }
                    }
                    bookButton.setEnabled(false);
                }
            }
            else
            {
            JOptionPane.showMessageDialog(this,"CHILD CANNOT BOOK AN R-RATED FILM OR UNACCOMPANIED BY AN ADULT IN AN M-RATED FILM", "BOOKING ERROR", JOptionPane.INFORMATION_MESSAGE, cross);
                
            for(int i = 0; i < SEAT_ROW; ++i)//resets the seats back if the bookings fail
                {
                    for(int k = 0; k < SEAT_COL; ++k)
                    {
                        seatButtons[i][k].setIcon(empty);
                        seatButtons[i][k].setText("[" + MovieSession.convertIndexToRow(i) + "/" + k + "]");
                        seatButtons[i][k].setHorizontalTextPosition(JButton.CENTER);
                        previousSeat[i][k] = 0;//reset the previousSeat booking array
                    }
                }
                currentReservation.removeAll(currentReservation);
            }
        }
        
        if(e.getSource() == cancelButton)//removes all bookings and clears the tentative bookings
        {                               
            for(int i = 0; i < SEAT_ROW; ++i)
            {
            for(int k = 0; k < SEAT_COL; ++k)
            {
                seatButtons[i][k].setIcon(empty);
                seatButtons[i][k].setText("[" + MovieSession.convertIndexToRow(i) + "/" + k + "]");
                seatButtons[i][k].setHorizontalTextPosition(JButton.CENTER); 
                bookButton.setEnabled(false);
                previousSeat[i][k] = 0;
            }
            }
            currentReservation.removeAll(currentReservation);
        }
        
        if(e.getSource() == exitButton)//exit the program
        {
            System.exit(0);
        }
    }
    
    public static void main (String[] args)
    {
        //create ArrayList of moviesessions and sort
        ArrayList<MovieSession> films = new ArrayList<>();
        
        Time movie1 = new Time(23,30,00);//set up films for the arraylist
        MovieSession thing = new MovieSession("The Thing", 'R', movie1);
        Time movie2 = new Time(21,00,00);
        MovieSession gremlins = new MovieSession("Gremlins", 'M', movie2);
        Time movie3 = new Time(17,30,00);
        MovieSession goonies = new MovieSession("The Goonies", 'G', movie3);
        Time movie4 = new Time(23,30,00);
        MovieSession robocop = new MovieSession("Robocop", 'R', movie4);
        Time movie5 = new Time(21,00,00);
        MovieSession china = new MovieSession("Big Trouble in Little China", 'M', movie5);
        Time movie6 = new Time(15,30,00);
        MovieSession tron = new MovieSession("Tron", 'G', movie6);
        
        films.add(tron);//add films to the arraylist
        films.add(thing);
        films.add(gremlins);
        films.add(goonies);
        films.add(robocop);
        films.add(china);
        
        Collections.sort(films);//sort the arraylist
        
        MovieBookingGUI movieGUI = new MovieBookingGUI(films);
        
        JFrame pendle = new JFrame("The Pendle Stairway - Classic Cinema Club");
        
        pendle.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pendle.getContentPane().add(movieGUI);
        pendle.pack();
        pendle.setResizable(false);
        
        Toolkit tool = Toolkit.getDefaultToolkit();
        Dimension dimension = tool.getScreenSize();
        int screenHeight = dimension.height;
        int screenWidth = dimension.width;
        pendle.setLocation(new Point((screenWidth / 2) - (pendle.getWidth() / 2), (screenHeight / 2) - (pendle.getHeight() / 2)));
        pendle.setVisible(true);
        
                
    }
}
