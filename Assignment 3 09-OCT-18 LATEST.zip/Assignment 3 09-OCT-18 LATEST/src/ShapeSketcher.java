
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

/*****TO DO*******
 * Fix when the shape is drawn offscreen
 * Save/Load from file
 */

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author matthewrook
 */
public class ShapeSketcher extends JPanel implements ActionListener, MouseListener, MouseMotionListener{
    

    private ArrayList<Shape> shapes;
    private JRadioButton line;
    private JRadioButton circle; 
    private JRadioButton oval; 
    private JRadioButton square; 
    private JRadioButton rectangle;
    private JButton clear;
    private JButton undo; 
    private JButton colour; 
    private JButton open;
    private JButton save;
    private JCheckBox fill;
    private JLabel northLabel;
    private final int PANEL_WIDTH = 500;
    private final int PANEL_HEIGHT = 500;
    private SketchPanel sketchPanel;
    private Shape currentShape;
    private Color colourChoice;
    
    public ShapeSketcher()
    {
//set up the panels
        super(new BorderLayout());
//northPanel setup
        JPanel northPanel = new JPanel();
        northLabel = new JLabel("Amiga 500 Deluxe Paint Lite");
        northLabel.setFont(new Font("Ariel", Font.BOLD, 20));
        northPanel.add(northLabel);
        add(northPanel, BorderLayout.NORTH);
        
//centerPanel for drawing
        sketchPanel = new SketchPanel();
        sketchPanel.addMouseListener(this);
        sketchPanel.addMouseMotionListener(this);
        add(sketchPanel, BorderLayout.CENTER);
        
//southPanel setup - Buttons
//Button instantiation
        colour = new JButton("Colour");
        colour.addActionListener(this);
        line = new JRadioButton("Line", true);
        circle = new JRadioButton("Circle");
        oval = new JRadioButton("Oval");
        square = new JRadioButton("Square");
        rectangle = new JRadioButton("Rectangle");
        undo = new JButton("Undo Shape");
        undo.addActionListener(this);
        clear = new JButton("Clear All");
        clear.addActionListener(this);
        open = new JButton("Open");
        open.addActionListener(this);
        save = new JButton("Save");
        save.addActionListener(this);
        fill = new JCheckBox("Shape Fill");
//Button Group setup
        ButtonGroup buttons = new ButtonGroup();
        buttons.add(colour);
        buttons.add(line);
        buttons.add(circle);
        buttons.add(oval);
        buttons.add(square);
        buttons.add(rectangle);
        buttons.add(undo);
        buttons.add(clear);
        buttons.add(open);
        buttons.add(save);
//add buttons to the south panel
        JPanel southPanel = new JPanel();
        southPanel.add(colour);
        southPanel.add(line);
        southPanel.add(circle);
        southPanel.add(oval);
        southPanel.add(square);
        southPanel.add(rectangle);
        southPanel.add(fill);
        southPanel.add(undo);
        southPanel.add(clear);
        southPanel.add(open);
        southPanel.add(save);     
        add(southPanel, BorderLayout.SOUTH);  
        
        shapes = new ArrayList<>();
        colourChoice = null;
    }
//mouselistener methods
    @Override
    public void mouseClicked(MouseEvent e) {
       
    }

    @Override
    public void mousePressed(MouseEvent e) {
        
        Object source = e.getSource();
        
        if(source == sketchPanel)
        {
            if(line.isSelected())
            {
                currentShape = new Line(e.getPoint());
                currentShape.setColour(colourChoice);
            }

            if(circle.isSelected())
            {
                currentShape = new Circle(e.getPoint());
                currentShape.setColour(colourChoice);
            }
            
            if(oval.isSelected())
            {
                currentShape = new Oval(e.getPoint());
                currentShape.setColour(colourChoice);
            }
            
            if(square.isSelected())
            {
                currentShape = new Square(e.getPoint());
                currentShape.setColour(colourChoice);
            }      
            
            if(rectangle.isSelected())
            {
                currentShape = new Rectangle(e.getPoint());
                currentShape.setColour(colourChoice);
            }                
            
            if(fill.isSelected() && currentShape instanceof EnclosesRegion)
            {
                EnclosesRegion region = (EnclosesRegion)currentShape;
                region.setFilled(true);
            } 
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
   
        if(e.getSource() == sketchPanel)
        {
            if(currentShape != null)
        {
        currentShape.setControlPoint(e.getPoint());
        shapes.add(currentShape);
        currentShape = null;
        }
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        
        if(e.getSource() == sketchPanel)
        {
        currentShape.setControlPoint(e.getPoint());
        repaint();
        }

    }

    @Override
    public void mouseMoved(MouseEvent e) {
    }
//private inner class for the sketching panel
    private class SketchPanel extends JPanel
    {
        public SketchPanel()
        {
            super();
            setPreferredSize(new Dimension(PANEL_WIDTH, PANEL_HEIGHT));
            setBackground(Color.white);
        }
        @Override
        public void paintComponent(Graphics g)
        {
            super.paintComponent(g);

            for(Shape s: shapes)// draw all shapes in the shapes arraylist
                s.draw(g); 
            if(currentShape != null)
            {
                currentShape.draw(g);  //draw the shape if current shape is not null
            
                //draw the H or V for vertical and horizontal if current shape is not null
                if(currentShape.startPoint.getX() == currentShape.controlPoint.getX())
                {
                    String vertical = ("V");
                    g.setColor(Color.BLACK);
                    g.drawString(vertical, (int)currentShape.controlPoint.getX()+10, (int)currentShape.controlPoint.getY()+10);
                }
                else if(currentShape.startPoint.getY() == currentShape.controlPoint.getY())
                {
                    String horizontal = ("H");
                    g.setColor(Color.BLACK);
                    g.drawString(horizontal, (int)currentShape.controlPoint.getX()+10, (int)currentShape.controlPoint.getY()+10);
                }
            }
        }
    }
    //action listener method for the buttons
    @Override
    public void actionPerformed(ActionEvent e)
    {
        //actions for each of the buttons
        Object source = e.getSource();
        
        if(source == colour)//messagebox to say choose a shape
        {
            colourChoice = JColorChooser.showDialog(ShapeSketcher.this, "Colour", Color.BLACK); 
        }
        if(source == undo)
        {
            //remove the shape from the arraylist to undo last shape drawn.
            if(!shapes.isEmpty())
            {
            shapes.remove(shapes.size() - 1);
            repaint();
            }         
        }
        if(source == clear)
        {               
            //remove the all shapes from the arraylist to remove all shapes drawn.
            shapes.clear();
            repaint();
        }
        if(source == open)
        {
            JFileChooser open = new JFileChooser(new File("."));
            int openButton = open.showOpenDialog(null);// change when have more info
            if(openButton == JFileChooser.APPROVE_OPTION)
            {
                try
                {
                    shapes = fileLoader(open.getSelectedFile().getAbsolutePath());
                    repaint();
                }
                catch(IOException f)
                {
                    JOptionPane.showMessageDialog(null, f, "FILE NOT FOUND", JOptionPane.ERROR_MESSAGE);
                }
                catch(ClassNotFoundException f)
                {
                    JOptionPane.showMessageDialog(null, f, "ERROR WITH OBJECT LOADING", JOptionPane.ERROR_MESSAGE);
                }
                
            }
        }
        if(source == save)
        {
            JFileChooser save = new JFileChooser(new File("."));
            int saveButton = save.showSaveDialog(null);
            
            if(saveButton == JFileChooser.APPROVE_OPTION)
            {
                try
                {
                fileSaver(shapes, save.getSelectedFile().getAbsolutePath());
                }
                catch(IOException f)
                {
                    JOptionPane.showMessageDialog(null, f, "ERROR SAVING FILE", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
    //helper method for saving a file
    public void fileSaver(ArrayList<Shape> list, String fileName) throws IOException
    {
        ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(fileName));
        output.writeObject(list);
        output.flush();
        output.close();
    }
    //helper method for loading a file
    public ArrayList<Shape> fileLoader(String fileName) throws IOException, ClassNotFoundException
    {
        ObjectInputStream input = new ObjectInputStream(new FileInputStream(fileName));
        ArrayList<Shape> list = (ArrayList<Shape>)input.readObject();
        input.close();
        return list;
    }
            
            
    public static void main(String[] args)
    {
        ShapeSketcher newPanel = new ShapeSketcher();
        JFrame frame = new JFrame("Shape Sketcher"); //create frame to hold JPanel subclass	
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.getContentPane().add(newPanel);  //add instance of shapesketcher to the frame
        frame.pack(); //resize frame to fit our Jpanel
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(new Point((d.width / 2) - (frame.getWidth() / 2), (d.height / 2) - (frame.getHeight() / 2)));
	//show the frame	
        frame.setVisible(true);
        
        
    }
}
