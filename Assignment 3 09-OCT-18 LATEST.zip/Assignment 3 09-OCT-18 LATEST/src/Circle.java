
import java.awt.Graphics;
import java.awt.Point;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author matthewrook
 */
public class Circle extends Oval{
    
    public Circle(Point startPoint)
    {
        super(startPoint);
    }
    @Override
    public void draw(Graphics g)
    {
        int width = ((int)controlPoint.getX()-(int)startPoint.getX());
        int height = ((int)controlPoint.getY()-(int)startPoint.getY());
        g.setColor(getColour());
        if(filled)     
            g.fillOval((width>height)?(int)startPoint.getX()-width:(int)startPoint.getX()-height,
                    (width>height)?(int)startPoint.getY()-width:(int)startPoint.getY()-height,(width>height)? 2*width:2*height, (width>height)? 2*width:2*height);
        else
            g.drawOval((width>height)? (int)startPoint.getX()-width:(int)startPoint.getX()-height,
                    (width>height)?(int)startPoint.getY()-width:(int)startPoint.getY()-height,(width>height)? 2*width:2*height, (width>height)? 2*width:2*height);
    }
}
