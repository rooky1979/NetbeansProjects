/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author matthewrook
 */
public class Time implements Comparable<Time>{
    
    private int hours;
    private int mins;
    private int secs;
 
    public Time()
    {
        setHours(0);
        setMinutes(0);
        setSeconds(0);
    }
    public Time(int hours)
    {
        setHours(hours);
    }
    public Time(int hours, int mins)
    {
        setHours(hours);
        setMinutes(mins);
    }
    Time(int hours, int mins, int secs)
    {
        setHours(hours);
        setMinutes(mins);
        setSeconds(secs);
    }
    public void setSeconds(int secs)
    {
       if (secs > 0 && secs < 59)
       {   
        this.secs = secs;
       }
    }
    public void setMinutes(int mins)
    {
       if (mins > 0 && mins < 59)
       {
        this.mins = mins;
       }
    }
    public void setHours(int hours)
    {
        if (hours > 0 && hours <= 23)
        {
        this.hours = hours;
        }
    }
    public int getSeconds()
    {
        return secs;
    }
    public int getMinutes()
    {
     return mins;   
    }
    public int getHours()
    {
        return hours;
    }
    @Override
    public boolean equals(Object otherTime)
    {    
        if (otherTime instanceof Time)
        {       
        Time t1 = (Time)otherTime;
        return this.hours == t1.hours && this.mins == t1.mins && this.secs == t1.secs;
        }
        else
        {
            return false;
        }
    }
    public String toString()
    {   
        int hour = getHours();
        int min = getMinutes();
        int sec = getSeconds();
        String clock = (((hour < 10) ? "0"+hour:hour) + ":" + ((min < 10) ? "0"+min:min) + ":" + ((sec < 10) ? "0"+sec:sec));
        
        return clock;
    }
    public int compareTo(Time otherTime)
    {
        int compare;
        
        compare = Integer.compare(this.hours, otherTime.hours);
        
        switch (compare) 
        {
            case 0:               
                switch (Integer.compare(this.mins, otherTime.mins)) 
                {
                    case 0:
                        switch (Integer.compare(this.secs, otherTime.secs)) 
                        {
                            case 1:
                                return 1;
                            case -1:
                                return -1;
                            default:
                                return 0;
                        }
                    case 1:
                        return 1;
                    
                    default:
                        return -1;
                }
            case 1:              
                return 1;
                
            default:
                return -1;
        }        
    }
}
