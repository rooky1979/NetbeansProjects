/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author matthewrook
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MovieSession implements Comparable<MovieSession> {
    
    private String movieName;
    private char rating;
    private Time sessionTime;
    private SeatReservation[][] sessionSeats;
    public final static int NUM_ROWS = 8;
    public final static int NUM_COLS = 6;
    
    public MovieSession(String movieName, char rating, Time sessionTime)
    {
        this.movieName = movieName;
        this.rating = rating;
        this.sessionTime = sessionTime;
        this.sessionSeats = new SeatReservation[NUM_ROWS][NUM_COLS];
        
    }
    public static int convertRowToIndex(char rowIndex)
    {
        switch(rowIndex)
        {
            case 'A':
                return 0;
            case 'B':
                return 1;
            case 'C':
                return 2;
            case 'D':
                return 3;
            case 'E':
                return 4;
            case 'F':
                return 5;
            case 'G':
                return 6;
            case 'H':
                return 7;
            default:
                return 9;
        }
    }
    public static char convertIndexToRow(int rowIndex)
    {
        switch(rowIndex)
        {
            case 0:
                return 'A';
            case 1:
                return 'B';
            case 2:
                return 'C';
            case 3:
                return 'D';
            case 4:
                return 'E';
            case 5:
                return 'F';
            case 6:
                return 'G';
            case 7:
                return 'H';
            default:
                return 'o';
        }
            
    }
    public char getRating()
    {
        return rating;
    }
    public String getMovieName()
    {
        return movieName;
    }
    public Time getSessionTime()
    {
        return sessionTime;
    }
    public SeatReservation getSeat(char row, int col)
    {
        if (convertRowToIndex(row) < NUM_ROWS || col < NUM_COLS || sessionSeats[convertRowToIndex(row)][col] != null);
        return sessionSeats[convertRowToIndex(row)][col];
    }
    public boolean isSeatAvailable(char row, int col)
    {
        return sessionSeats[convertRowToIndex(row)][col] == null;
    }
    public boolean applyBookings(List<SeatReservation> reservations)
    {
        int child = 0;
        int adult = 0;
        
        for(int i = 0; i < reservations.size(); ++i)
        {
            if(isSeatAvailable(reservations.get(i).getRow(), reservations.get(i).getCol()) != true)
                
                return false;
        }
        for (int a = 0; a < reservations.size(); ++a)
        {
            if(reservations.get(a) instanceof ChildReservation && rating == 'R')

                return false;
        }
        if (rating == 'M')
        {
            for (int k = 0; k < reservations.size(); ++k)
            {
                if (reservations.get(k) instanceof AdultReservation || reservations.get(k) instanceof ElderlyReservation)
                    adult += 1;
                else
                    child += 1;
                
            }
            if (child > 0 && adult < 1)
                return false;
        }
         for (int m = 0; m < reservations.size(); ++m)
            {
                int row = convertRowToIndex(reservations.get(m).getRow());
                int col = reservations.get(m).getCol();
                sessionSeats[row][col] = reservations.get(m);
            }
        return true;
    }
    public void printSeats()
    {
        for (int i = 0; i < NUM_ROWS; ++i)
        {
            for (int k = 0; k < NUM_COLS; ++k)
            {
                if(sessionSeats[i][k] instanceof ChildReservation)
                {
                  System.out.printf("|C|");
                }
                else if (sessionSeats[i][k] instanceof AdultReservation)
                {
                  System.out.printf("|A|");
                }
                else if (sessionSeats[i][k] instanceof ElderlyReservation)
                {
                  System.out.printf("|E|");
                }
                else
                  System.out.printf("|_|");
            }
            System.out.println("");
        }
    }
    public String toString()
    {
        return (getMovieName() + " (" + getRating() + ") - " + getSessionTime());
    }
    public int compareTo(MovieSession otherSession)
    {
        int compare;
        
        compare = this.sessionTime.compareTo(otherSession.sessionTime);
        
        switch(compare)
        {
            case 0:
                int compareName = this.movieName.compareTo(otherSession.movieName);
                {
                    if (compareName == 0)
                        return 0;
                    else if (compareName > 0)
                        return 1;
                    else if (compareName < 0)
                        return -1;
                }
                
            case 1:
                return 1;
                
            default:
                return -1;
        }
    }
    
    
    public static void main(String[] args)//For testing the booking
    {
        /*ArrayList<MovieSession> movies = new ArrayList<>();//new array list for films
        ArrayList<SeatReservation> currentReservation = new ArrayList<>();//array list to test the bookings
        
        ChildReservation child = new ChildReservation('C', 2);//set up reservations
        AdultReservation adult = new AdultReservation('C', 3);
        AdultReservation adult1 = new AdultReservation('D', 5);
        ElderlyReservation elderly = new ElderlyReservation('G',0);
        
        Time movie1 = new Time(23,30,00);//set up films for the arraylist
        MovieSession thing = new MovieSession("The Thing", 'R', movie1);
        Time movie2 = new Time(21,00,00);
        MovieSession gremlins = new MovieSession("Gremlins", 'M', movie2);
        Time movie3 = new Time(17,30,00);
        MovieSession goonies = new MovieSession("The Goonies", 'G', movie3);
        Time movie4 = new Time(23,30,00);
        MovieSession robocop = new MovieSession("Robocop", 'R', movie4);
        Time movie5 = new Time(21,00,00);
        MovieSession china = new MovieSession("Big Trouble in Little China", 'M', movie5);
        Time movie6 = new Time(15,30,00);
        MovieSession tron = new MovieSession("Tron", 'G', movie6);
        
        movies.add(tron);//add films to the arraylist
        movies.add(thing);
        movies.add(gremlins);
        movies.add(goonies);
        movies.add(robocop);
        movies.add(china);
        
        for (int i = 0; i < movies.size(); ++i)//testing the arraylist and printing to console
        {
            System.out.println(movies.get(i));
        }
            Collections.sort(movies);//sort the arraylist

        System.out.println("");
        
        for (int i = 0; i < movies.size(); ++i)//testing the sorted list and printing to console
        {
            System.out.println(movies.get(i));
        }
        System.out.println("");
//Test bookings for G rated film
        currentReservation.add(adult);
        currentReservation.add(child);
        currentReservation.add(elderly);
        
        if(goonies.applyBookings(currentReservation));
        System.out.println("ALL BOOKINGS SUCCESSFULL");   
        goonies.printSeats();//test that the seats are reserved in the sessionSeats array
//Test bookings for R rated film        
        //currentReservation.add(child);
        
        if (!(robocop.applyBookings(currentReservation)))
            System.out.println("CHILD CANNOT BOOK AN R RATED FILM OR M RATED FILM UNACCOMPANIED BY AN ADULT");
        robocop.printSeats();//confirm the seat was not booked
        
        System.out.println("");
        
        currentReservation.add(adult);
        currentReservation.add(elderly);
        currentReservation.add(child);
        if (!(robocop.applyBookings(currentReservation)))
            System.out.println("CHILD CANNOT BOOK AN R RATED FILM OR M RATED FILM UNACCOMPANIED BY AN ADULT");
        robocop.printSeats();//confirm the seats are in the sessionSeat array
        
        System.out.println("");
 //Test the M rated film       
        currentReservation.add(child);
        if (!(gremlins.applyBookings(currentReservation)))
            System.out.println("CHILD CANNOT BOOK AN R RATED FILM OR M RATED FILM UNACCOMPANIED BY AN ADULT");
        gremlins.printSeats();//confirm the seats are in the sessionSeat array
        
        System.out.println("");
        
        currentReservation.add(child);
        currentReservation.add(elderly);
        if (!(gremlins.applyBookings(currentReservation)))
            System.out.println("CHILD CANNOT BOOK AN R RATED FILM OR M RATED FILM UNACCOMPANIED BY AN ADULT");
        gremlins.printSeats();//confirm the seats are in the sessionSeat array
 //Test for already booked seats       
        currentReservation.add(child);
        currentReservation.add(elderly);
        if (!(gremlins.applyBookings(currentReservation)))
            System.out.println("Seats are already booked");
        gremlins.printSeats();*/
    }
}
