
import java.awt.Graphics;
import java.awt.Point;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author matthewrook
 */
public class Square extends Rectangle{//change to extend whichever needs to be sq ext rec or rec ext sq
    
    public Square(Point startPoint)//change to include startpoint when needed
    {
        super(startPoint);
    }
    @Override
    public void draw(Graphics g)
    {
        int x = (int)controlPoint.getX()-(int)startPoint.getX();
        int y = (int)controlPoint.getY()-(int)startPoint.getY();
        g.setColor(getColour());
        if(filled)     
            g.fillRect((int)startPoint.getX(), (int)startPoint.getY(),(x > y)? x:y , (x > y)? x:y);
        else
            g.drawRect((int)startPoint.getX(), (int)startPoint.getY(),(x > y)? x:y , (x > y)? x:y);
    }
}

//(controlPoint.getX()-startPoint.getX > controlPoint.getY()-startPoint.getY())? g.fillRect