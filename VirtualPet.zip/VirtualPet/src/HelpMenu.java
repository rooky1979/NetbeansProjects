
import java.util.Random;

/*  VIRTUAL PET PROGRAM BASED ON THE 90'S HANDHELD LCD KEYCHAIN GAME*/
/**
 *
 * @author matthewrook - 18007407
 */
public class HelpMenu {// contains helper methods 
    
    public static void helpMenu()
    {
        System.out.println("Type 'Instructions' for game instructions"); 
        System.out.println("Type 'Feed' to feed the pet");
        System.out.println("Type 'Wash' to wash the pet");
        System.out.println("Type 'Sleep' to put the pet to bed");
        System.out.println("Type 'Play' to give the pet a toy");
        System.out.println("Type 'Heal' to heal the pet when sick");
        System.out.println("Type 'Cleanup' to clean up any poop");
        System.out.println("Type 'Status' to check the pet's current stats");
        System.out.println("Type 'Age' to see how old your pet is");
        System.out.println("Type 'Quit' to save the pet's state and exit the game\n");
    }
    
    public static void gameInstructions()
    {
            System.out.println("Your pet needs to be looked after. It must be fed when hungry, given a toy when sad.");
            System.out.println("Put to bed when sleepy, washed when dirty, healed when sick and its poops must be cleaned up when it goes to the bathroom.\n");
            System.out.println("At the end of each command entered, a random life event will occur such as stats will reduce, the pet will get sick or the pet will poop.\n");
            System.out.println("**IMPORTANT** If your pet's hunger is 0, or reaches Level 6 sickness, it will die and cannot be brought back to life and is lost forever :(");
            System.out.println("Type Help to look at the commands to care for your pet\n");
    }
    
    public static String speciesSelector()// selects a random species upon hatching
    {
        Random rand = new Random();
        int species = rand.nextInt(3);
        
        switch(species)
        {
            case 0:
                return "SNOZZCUMBER";
            case 1:
                return "LIMBERFLUMP";
            case 2:
                return "ROCKYPOCK";
            default:
                return "No Species Hatched";
        }       
    }
}

   
