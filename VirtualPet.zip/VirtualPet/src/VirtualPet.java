
import java.io.Serializable;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

/*  VIRTUAL PET PROGRAM BASED ON THE 90'S HANDHELD LCD KEYCHAIN GAME*/
/**
 *
 * @author matthewrook - 18007407
 */
public class VirtualPet implements Serializable{
    
    private String speciesName;
    private String nickName;
    private int hunger; 
    private int awakeness;
    private int mood; 
    private int hygiene; 
    private int petAge;
    private int sicknessLevel;
    private int poopAmount;
    private boolean isSick; 
    private boolean hasPooped;
    private final int MIN_STAT = 0;
    private final int MAX_STAT = 100;
            
    public VirtualPet()
    {
        
    }
    
    public VirtualPet(String speciesName)
    {
        setSpeciesName(speciesName);
        setHunger(MAX_STAT);
        setAwakeness(MAX_STAT);
        setMood(MAX_STAT);
        setHygiene(MAX_STAT);
        setPetAge(MIN_STAT);
        setHasPooped(false);
        setIsSick(false);
        setSicknessLevel(MIN_STAT);
    }

    public void setSpeciesName(String speciesName) 
    {
        this.speciesName = speciesName;
    }

    public String getSpeciesName() 
    {
        return speciesName;
    }
    
    public void setNickName(String nickName) 
    {
        this.nickName = nickName;
    }

    public String getNickName() 
    {
        return nickName;
    }
    public void setHunger(int hunger)
    {
        this.hunger = hunger;
    }
    
    public int getHunger()
    {
        return this.hunger;
    }
    
    public void setAwakeness(int awakeness)
    {
        this.awakeness = awakeness;
    }
    
    public int getAwakeness()
    {
        return this.awakeness;
    }
    
    public void setMood(int mood)
    {
        this.mood = mood;
    }
    
    public int getMood()
    {
        return this.mood;
    }
    
    public void setHygiene(int hygiene)
    {
        this.hygiene = hygiene;
    }
    
    public int getHygiene()
    {
        return this.hygiene;
    }
    
    public void setPetAge(int petAge)
    {
        this.petAge = petAge;
    }
    
    public int getPetAge()
    {
        return this.petAge;
    }
    
    public void setSicknessLevel(int sickness)
    {
        this.sicknessLevel = sickness;
    }
    
    public int getSicknessLevel()
    {
        return this.sicknessLevel;
    }
    
    public void setPoopAmount(int poop)
    {
        this.poopAmount = poop;
    }
    
    public int getPoopAmount()
    {
        return this.poopAmount;
    }
    public boolean getHasPooped()
    {
        return hasPooped;
    }
    
    public void setHasPooped(boolean poop)
    {
        this.hasPooped = poop;
    }
    
    public void setIsSick(boolean sick)
    {
        this.isSick = sick;
    }
    
    public boolean getIsSick()
    {
        return isSick;
    }
    
    public void giveFood() // increases hunger stat
    {
        if (hunger < MAX_STAT) 
        {          
            System.out.println("Yummy! A Cheeseburger.  My favourite!");
            hunger = MAX_STAT; 
            System.out.println("Hunger: " + hunger + "\n");
        }
        else
        {
            System.out.println("I'm not hungry at the moment...\n");
        }
    }
    
    public void playtime()//increases mood stat
    {
        if (mood < MAX_STAT)
        {
            if(awakeness >= 10)// if the pet is too tired it doesn't want to play, player needs to give the pet a nap before playing to increase the mood
            {
                System.out.println("Yippee!!! my favorite toy THANK YOU!!!");
                mood = MAX_STAT;
                System.out.println("Mood: " + mood + "\n");
            }
            else
            {
                System.out.println("I'm too sleepy to play.  I need a nap first......\n");  
            }                   
        }
        else
        {
            System.out.println("I'm already happy and don't want to play right now!\n");
        }
    }
    
    public void sleep()//increases the awakeness stat
    {
        if (awakeness < MAX_STAT)
        {
            System.out.println("YAWWWWWN! I'm sleepy, time for a nap.....");
            System.out.println("ZZZZZzzzzz");
            System.out.println("ZZZZZzzzzz");
            System.out.println("ZZZZZzzzzz");
            System.out.println("ZZZZZzzzzz");
            System.out.println("ZZZZZzzzzz");
            System.out.println("That's better.  Now I'm nice and awake!");
            awakeness = MAX_STAT;            
            System.out.println("Awakeness: " + awakeness + "\n");
        }
        else
        {
            System.out.println("I'm not sleepy, I don't need to go to bed right now!\n");
        }
    }
    
    public void giveWash()//increases the hygiene stat
    {
        if (hygiene < MAX_STAT)
        {
            System.out.println("Yay! Bath time!");
            hygiene = MAX_STAT;
            System.out.println("Hygiene: " + hygiene + "\n");
        }
        else
        {
            System.out.println("I'm already clean! I don't need a wash!\n");
        }
    }
    
    public void cleanup(boolean poop)//cleanup poops
    {
        if (poop == true)// there are poops to clean up
        {
            System.out.println("Poops have all been cleaned up!\n");
            poopAmount = 0;//poops return to none
            hasPooped = false;//returns to false that there are no poops
        }
        else
        {
            System.out.println("There are no poops to clean up!\n");
            hasPooped =  false; //stays false as there are no poops to clean
        }
    }
    
    public void heal(boolean sick)//heal the pet
    {
        if (sick == true)// the pet is sick
        {
            System.out.println("Ahh that medicine made me feel so much better thanks!\n");
            sicknessLevel = 0;
            isSick = false;// returns false after pet is healed
        }
        else
        {         
            System.out.println("I don't need medicine, I feel fine!\n");
            isSick = false;// stays false as the pet is not sick
        }       
    }     
    
    public void checkStatus()// to print the current pet stats
    {
        System.out.println("\nPet Age: " + getPetAge() + " Hunger: " + getHunger() + " Awakeness: " + getAwakeness()); 
        System.out.println("Mood: " + getMood() + " Hygiene: " + getHygiene());
        System.out.println(((!getIsSick()) ? "Pet is not sick":"Pet is sick") + "\nSickness Level: " + getSicknessLevel() + ((!getHasPooped()) ? "\nPet has not pooped" : "\nPet has pooped"));
        System.out.println("Poops to clean: " + getPoopAmount()+ "\n");
    }
    
    public String toString()
    {
        return "YOU HAVE HATCHED A " + getSpeciesName() + "!!!\n";
    }
    
    public boolean lifeCycle()// method to perform a random event at the end of each turn/command given
    {
        Random random = new Random();
        boolean life = true;
        
        switch(random.nextInt(6))// randomiser to determine the event to perform
        {
            case 0:// event to reduce the hunger stat
                
                if(getHunger() >= 2)
                {
                    setHunger(getHunger()- 2);
                    System.out.println("Hunger reduced by 2...\n");
                        
                    if(getHunger() < 10)
                        {
                            System.out.println("QUICK! YOUR PET'S HUNGER IS CLOSE TO 0!!! FEED IT NOW TO KEEP IT ALIVE!!!!!\n");
                        }
                }               
                else if(getHunger() <= MIN_STAT)
                {
                    System.out.println("Hunger reduced by 2...");
                    System.out.println("Oh No! Your " + getSpeciesName() + ", " + getNickName() + 
                    " has died from starvation!\n!!!!!!!GAME OVER!!!!!!!\nYou cannot reload or revive this pet.  You will need to hatch a new pet.\nNext time, take more care of your pet!\n");
                    
                    FileIO.deleteFile();//the static method looks for a .txt file and deletes it
                    life = false;//returns false for the check in main
                }
                break;

            
            case 1:// event for reducing awakeness
                
                if(getAwakeness() >= 2)
                {
                    setAwakeness(getAwakeness() - 2);
                    System.out.println("Awakeness reduced by 2...\n");
                }
                else if(getAwakeness() <=MIN_STAT)
                {
                    System.out.println("YAAAAAWWWWWWWNNNNN!!!!  I'M SO SLEEPY! PLEASE PUT ME TO BED!!!!\n");
                }
                break;
            
            case 2://event for reducing the mood stat
                
                if(getMood() >= 2)
                {
                    setMood(getMood() - 2);
                    System.out.println("Mood reduced by 2...\n");
                }
                else if (getMood() <= MIN_STAT)
                {
                    System.out.println("I AM SOO GRUMPY AND BORED!!!!!!  PLAY WITH ME!!!!!!!NOW!\n");
                }
                break;
                
            case 3://event to reduce hygiene and make the pet sick if gets too dirty.  The pet dies if it doesn't get healed
                
                if(getHygiene() >= 2)
                {
                    setHygiene(getHygiene() - 2);
                    System.out.println("Hygiene reduced by 2...\n");
                }
                else if(getHygiene() <= MIN_STAT)
                {
                    System.out.println("I AM FILTHY! PLEASE GIVE ME A WASH!!!!!\n");
                    setIsSick(true);
                    setSicknessLevel(getSicknessLevel() + 1);// if pet is filthy, it makes the pet sick and adds a 1 to the sickness level until the pet is washed with the possibility of death if not healed and washed
                    System.out.println("THE PET IS DIRTY AND IT IS MAKING HIM SICK!!! WASH THE PET AND HEAL IT!");
                    System.out.println("Sickness Level: " + getSicknessLevel());
                    
                    if(getSicknessLevel() == 5)
                        {
                            System.out.println("QUICK!!!! YOUR PET IS AT LEVEL 5 SICKNESS.....  HEAL IT NOW IF IT REACHES LEVEL 6 IT WILL BE FATAL!!!!!!!!!");
                        }
                    if(getSicknessLevel() > 5)
                    {
                    System.out.println("Oh No! Your " + getSpeciesName() + ", " + getNickName() + 
                    " has died from a Level 6 sickness!\n!!!!!!!GAME OVER!!!!!!!\nYou cannot reload or revive this pet.  You will need to hatch a new pet.\nNext time, take more care of your it!\n");
                    
                    FileIO.deleteFile();//delete the pet file if applicable
                    life = false;
                    }
                }
                break;                
                
            case 4://event for the pet to randomly poop
                
                setHasPooped(true);
                setPoopAmount(getPoopAmount()+ 1);
                System.out.println(getNickName() + " HAS POOPED! IT NEEDS TO BE CLEANED UP!\nAmount of poops to clean up: " + getPoopAmount());            
                break;
                
            case 5://event for the pet to get randomly sick
                
                setIsSick(true);
                
                if(getSicknessLevel() < 6)
                {
                setSicknessLevel(getSicknessLevel() + 1);
                System.out.println("Oh No! " + getNickName() + " is sick!!!  Quick give it some medicine!!!\nSickness Level = " + getSicknessLevel());
                
                        if(getSicknessLevel() == 5)
                        {
                            System.out.println("QUICK!!!! YOUR PET IS AT LEVEL 5 SICKNESS.....  HEAL IT NOW IF IT REACHES LEVEL 6 IT WILL BE FATAL!!!!!!!!!");
                        }
                }
                if(getSicknessLevel() > 5)
                {
                    System.out.println("Oh No! Your " + getSpeciesName() + ", " + getNickName() + 
                    " has died from a Level 6 sickness!\n!!!!!!!GAME OVER!!!!!!!\nYou cannot reload or revive this pet.  You will need to hatch a new pet.\nNext time, take more care of your it!\n");
                    
                    FileIO.deleteFile();
                    life = false;
                }        
                break;           
        }
        
        setPetAge(getPetAge() + 1);//increase the pet age at the end of each turn
                
        if(getPetAge() == 3)
        {
            System.out.println("Your " + getSpeciesName() +" is 3 and no longer a baby.  It has evolved into a toddler!\n");
        }
        if(getPetAge() == 15)
        {
            System.out.println("Your " + getSpeciesName() +" is 15 and no longer a toddler.  It has evolved into a teenager!\n");
        }
        if(getPetAge() == 30)
        {
            System.out.println("Your " + getSpeciesName() +" is 30 and no longer a teenager.  It has evolved into an adult!\n");
        }
        if(getPetAge() == 65)
        {
            System.out.println("Your " + getSpeciesName() +" is 65 and no longer an adult.  It has evolved into an granny pet!\n");
        } 
        return life;
    }
    

}