
import java.io.IOException;
import java.util.Scanner;

/*  VIRTUAL PET PROGRAM BASED ON THE 90'S HANDHELD LCD KEYCHAIN GAME*/
/**
 *
 * @author matthewrook - 18007407
 */
public class PetMain {

    public static void main (String[] arg) throws IOException, ClassNotFoundException
    {
        Scanner scan = new Scanner(System.in);
        String command = "";
        boolean flag = false;// flag to kick out of the do while loop

        if(FileIO.checkFile())// check to see if there is an active pet to care for
        {
          VirtualPet pet = (VirtualPet)FileIO.fileloader();// if file present, pet object is loaded and the game continues
          
          System.out.println("Welcome Back! " + "Your " + pet.getSpeciesName() + ", " + pet.getNickName() + " has missed you!");
          
          do
            {    
                System.out.println("What would you like to do with " + pet.getNickName()+ " ?");
            
                command = scan.nextLine();
            
                if("help".equals(command.toLowerCase()))
                {
                    HelpMenu.helpMenu();
                }
                else if("instructions".equals(command.toLowerCase()))
                {
                    HelpMenu.gameInstructions();
                }
                else if("feed".equals(command.toLowerCase()))
                {
                    pet.giveFood();
                }
                else if("wash".equals(command.toLowerCase()))
                {
                    pet.giveWash();
                }
                else if("sleep".equals(command.toLowerCase()))
                {
                    pet.sleep();
                }
                else if("play".equals(command.toLowerCase()))
                {
                    pet.playtime();
                }
                else if("heal".equals(command.toLowerCase()))
                {                
                    pet.heal(pet.getIsSick());
                }
                else if("cleanup".equals(command.toLowerCase()))
                {
                    pet.cleanup(pet.getHasPooped());
                }
                else if("status".equals(command.toLowerCase()))
                {
                    pet.checkStatus();
                }
                else if("age".equals(command.toLowerCase()))
                {
                    System.out.println("Pet Age: " + pet.getPetAge());
                }
                else if("quit".equals(command.toLowerCase()))
                {
                    FileIO.filesaver(pet);//pet object is saved
                    flag = true;//flag changes to true to kick out of the do while loop                
                }
                else
                {
                    System.out.println("\nIncorrect command entered.  Try again or type \"Help\" to see the command list.\n");// handles incorrect user input
                }
                
                if(!flag)
                {                
                    System.out.println("END OF TURN EVENT:\n");

                    if(!pet.lifeCycle())//performs the random end of turn event. If the pet dies, lifecycle() returns false
                    {
                        flag = true;        
                    }
                }
            }while(!flag);
        }
        
        else // if there is no file saved, a new save game begins
        {
            VirtualPet pet = new VirtualPet(HelpMenu.speciesSelector());// selects one of three possible species
     
            System.out.println(pet.toString());
        
            System.out.println("Give your " + pet.getSpeciesName() + " a name!");
            pet.setNickName(scan.nextLine());
        
            System.out.println("\nGreat! You have named your " + pet.getSpeciesName() + " " + "\"" + pet.getNickName() + "\"" + "\n");
        
            HelpMenu.gameInstructions();//initial game instructions printed
            System.out.println("\n");
            HelpMenu.helpMenu();// initial commands printed
            System.out.println("\n");
        
            do
            {    
                System.out.println("What would you like to do with " + pet.getNickName()+ " ?");
            
                command = scan.nextLine();
            
                if("help".equals(command.toLowerCase()))
                {
                    HelpMenu.helpMenu();
                }
                else if("instructions".equals(command.toLowerCase()))
                {
                    HelpMenu.gameInstructions();
                }
                else if("feed".equals(command.toLowerCase()))
                {
                    pet.giveFood();
                }
                else if("wash".equals(command.toLowerCase()))
                {
                    pet.giveWash();
                }
                else if("sleep".equals(command.toLowerCase()))
                {
                    pet.sleep();
                }
                else if("play".equals(command.toLowerCase()))
                {
                    pet.playtime();
                }
                else if("heal".equals(command.toLowerCase()))
                {                
                    pet.heal(pet.getIsSick());
                }
                else if("cleanup".equals(command.toLowerCase()))
                {
                    pet.cleanup(pet.getHasPooped());
                }
                else if("status".equals(command.toLowerCase()))
                {
                    pet.checkStatus();
                }
                else if("age".equals(command.toLowerCase()))
                {
                    System.out.println("\nPet Age: " + pet.getPetAge());
                }
                else if("quit".equals(command.toLowerCase()))
                {
                
                    FileIO.filesaver(pet);//pet object is saved
                    flag = true;    //kicks out of the do while loop              
                }
                else
                {
                    System.out.println("Incorrect command entered.  Try again or type \"Help\" to see the command list.\n");// handle incorrect user input
                }
                      
                if(!flag)
                {                
                    System.out.println("END OF TURN EVENT:\n");
                    if(!pet.lifeCycle())//performs the random end of turn event. If the pet dies, lifecycle() returns false
                    {
                        flag = true;        
                    }
                }
            }while(!flag);
        }
    }        
}

