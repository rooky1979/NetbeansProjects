
import java.awt.Graphics;
import java.awt.Point;
import java.io.Serializable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author matthewrook
 */
public class Rectangle extends Shape implements EnclosesRegion{
    
    protected boolean filled;
    
    public Rectangle(Point startPoint)//change to include startpoint when needed
    {
        super(startPoint);
    }
    @Override
    public void draw(Graphics g)
    {
        //draw the rectangle.  change if incorrect
        g.setColor(getColour());
        if(filled)
            g.fillRect((int)startPoint.getX(), (int)startPoint.getY(), (int)controlPoint.getX()-(int)startPoint.getX(), (int)controlPoint.getY()-(int)startPoint.getY());
        else
            g.drawRect((int)startPoint.getX(), (int)startPoint.getY(), (int)controlPoint.getX()-(int)startPoint.getX(), (int)controlPoint.getY()-(int)startPoint.getY());
    }
    @Override
    public void setFilled(boolean filled)
    {
        this.filled = filled;
    }
}
