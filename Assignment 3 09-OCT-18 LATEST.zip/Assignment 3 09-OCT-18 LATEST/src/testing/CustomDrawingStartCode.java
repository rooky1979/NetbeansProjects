package testing;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author sehall
 */
public class CustomDrawingStartCode extends JPanel{
    public final int PANEL_WIDTH = 400;
    public final int PANEL_HEIGHT = 400;
    private DrawingPanel drawPanel;  //innerclass
    
    public CustomDrawingStartCode() {
        super(new BorderLayout());   //invoke super class Jpanel constructor use BorderLayout
        drawPanel = new DrawingPanel();     //create DrawingPanel and add to center
        add(drawPanel, BorderLayout.CENTER);  
    }
    //seperate inner class for graphics
    private class DrawingPanel extends JPanel
    {   public DrawingPanel()
        {   setPreferredSize(new Dimension(PANEL_WIDTH, PANEL_HEIGHT));
            setBackground(Color.WHITE);
        }
        @Override
        public void paintComponent(Graphics g){
            super.paintComponent(g);
            g.setColor(Color.BLACK);  //dip paint brush in black
            g.fillRect(0, 0, 200,100);//top left corner coordinate,width & height
            g.setColor(Color.YELLOW); //dip paint brush in yellow
            g.drawOval(0,0,100,100);//top left corner coordinate,width & height
            g.fillOval(100,0,100,100);

            //can do all drawing here using Graphics object g.
        }
    }
    public static void main(String[] args) {
        CustomDrawingStartCode myPanel = new CustomDrawingStartCode();
        JFrame frame = new JFrame("Custom Drawing"); //create frame to hold our JPanel subclass	
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.getContentPane().add(myPanel);  //add instance of MyGUI to the frame
        frame.pack(); //resize frame to fit our Jpanel
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(new Point((d.width / 2) - (frame.getWidth() / 2), (d.height / 2) - (frame.getHeight() / 2)));
	//show the frame	
        frame.setVisible(true);
    }
}